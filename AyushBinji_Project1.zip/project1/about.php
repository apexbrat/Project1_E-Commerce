<!doctype html>
<html lang="en">
    <head>
        <title>About Us | Bibliophile</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="style.css">
    </head>
        <body>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="index.php">#Bibliophile</a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bookstore.php">Select Books</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="checkout.php">Checkout</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <br>
            <div class="centerbox">
                <img src="images/aboutpic.jpeg" alt="About Image">
                <h2>About Us</h2>
                <p>Waterstones began in 1982 under the aegis of its founder, Tim Waterstone. Over the decades that have followed, we have grown to become an icon of the British cultural landscape, employing over 3000 superb booksellers across over 280 bookshops.</p>
                <p>As the last surviving national bookshop chain, under the helmsmanship of Managing Director James Daunt, we are proud to have fought off the perceived threat of e-readers and online competition to begin a programme of active expansion. Recent years have seen fresh shops open around the country and sites either move or be upgraded. With recent openings including Reigate, Clifton and moves to far more attractive locations for our shops in Edinburgh and Manchester’s Trafford Centre, our plans continue to be ambitious.</p>
                <p>Working closely with our bookshops are our efforts online, where at Waterstones.com we are working to bring the very essence of Waterstones to every home and smartphone in Britain. With hugely popular endeavours such as our regular reading update Waterstones Weekly and an ever-increasing offering of exclusive reader offers and signed editions, Waterstones.com is the perfect online companion to our High Street bookshops. Click & Collect – the service that links the two – has grown in tandem with our success, allowing our customers to experience the best of both worlds.</p>
                <p>Through our own coffee shops, range of books, our array of gifts and booksellers who genuinely love what they sell, we welcome you to Waterstones.</p>
            </div>
            <br>
            <footer><p>#Bibliophile &copy; Copyright 2021 by Ayush Binji</p></footer>
        </body>
</html>