<!doctype html>
<html lang="en">
    <head>
        <title>Checkout | Bibliophile</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="style.css">
    </head>
        <body>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="index.php">#Bibliophile</a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bookstore.php">Select Books</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="checkout.php">Checkout</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container">
                <br>
                <div class="center-sort">
                    <form method="POST" action="checkout.php">
                        <p>Firstname: <input type="text" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>"></p>
                        <p>Lastname: <input type="text" name="lname" value="<?php if(isset($_POST['lname'])) echo $_POST['lname']; ?>"></p>
                        <p>Email: <input type="text" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>"></p>
                        <p>Phone: <input type="text" name="phone" value="<?php if(isset($_POST['phone'])) echo $_POST['phone']; ?>"></p>
                        <label>Payment Method:</label>
                        <select name="pay">
                            <option value="">Select an option</option>
                            <option value="Credit/Debit Card">Credit/Debit Card</option>
                            <option value="Cash">Cash</option>
                            <option value="COD">Cash on Delivery</option>
                        </select>
                        <p><input type="submit" value="Place Order" name="submit"></p>
                    </form>

                    <?php
            
                        session_start();

                        $q1 = array();
                        parse_str($_SERVER['QUERY_STRING'], $q1);

                        require('mysqli_connect.php');
                        if(isset($q1['ID'])){

                            $id = $q1['ID'];
                            $q1 = "SELECT book_ID, book_name, book_price, book_bio, book_pub_year, book_stock, auth_name, pub_name, cat_name FROM author
                            JOIN books ON author.auth_ID = books.auth_ID
                            JOIN publisher ON books.pub_ID = publisher.pub_ID
                            JOIN category ON books.cat_ID = category.cat_ID";

                            $r1 = $connection->query($q1);
                
                            if ($r1->num_rows > 0) {
                                while($row = $r1->fetch_assoc()) {
                                    $_SESSION['ID'] = $row['book_ID'];
                                    $_SESSION["book"] = $row['book_name'];
                                    $_SESSION["price"] = $row['book_price'];
                                    $_SESSION["bio"] = $row['book_bio'];
                                    $_SESSION["pyear"] = $row['book_pub_year'];
                                    $_SESSION["stock"] = $row['book_stock'];
                                    $_SESSION["author"] = $row['auth_name'];
                                    $_SESSION["publisher"] = $row['pub_name'];
                                    $_SESSION["category"] = $row['cat_name'];
                                }
                            }
                        }

                        $err = array();
                        
                        if($_SERVER["REQUEST_METHOD"] == "POST") {
                                
                            $firstname = $_POST['fname'];
                            $lastname = $_POST['lname'];
                            $payment = $_POST['pay'];
                            $email = $_POST['email'];
                            $phone = $_POST['phone'];
                            $id= $_SESSION['ID'];

                            if(!empty($_POST['$firstname']) || strlen($firstname) == 0){
                                array_push($err, "Please enter your firstname.<br>");
                            }else {
                                $firstname = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
                            }

                            if(!empty($_POST['$lastname']) || strlen($lastname) == 0){
                                array_push($err, "Please enter your lastname.<br>");
                            }else {
                                $lastname = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
                            }

                            if(!empty($_POST['$payment']) || strlen($payment) == 0){
                                array_push($err, "Please select one payment method.<br>");
                            }else {
                                $payment = filter_var($_POST['pay'], FILTER_SANITIZE_STRING);
                            }
                            
                            if(!empty($_POST['$email']) || strlen($email) == 0){
                                array_push($err, "Please enter your email address.<br>");
                            }else {
                                $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
                            }
                            
                            if(!empty($_POST['$phone']) || strlen($phone) == 0){
                                array_push($err, "Please enter your phone number.<br>");
                            }else {
                                $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
                            }                   
                            
                            if(empty($err))
                            {
                                $q2 = "INSERT INTO orders (order_fname, order_lname, order_pay, order_email, order_phone)
                                        VALUES ('$firstname','$lastname','$payment ','$email','$phone')";
                                
                                $r2 = mysqli_query($connection, $q2);

                                $sql = "SELECT * FROM books WHERE book_ID = $id";
                                $q3 = mysqli_query($connection,$sql) or die( mysqli_error($connection));
                                $r3 = mysqli_fetch_array($q3);
                                $stockval = $r3['book_stock'];

                                $stockupdated = $stockval - 1;

                                $newstock = mysqli_query($connection,"UPDATE books SET book_stock = '$stockupdated' WHERE book_ID = $id");
                                
                                if($r2 || $newstock)
                                {
                                    header("Location: success.php");
                                }
                                else
                                {
                                    echo "Order not placed";
                                }
                            } else {
                                foreach($err as $e) {
                                    echo $e, '<br>';
                                }
                                
                            } 
                        }
                        mysqli_close($connection);
                    ?>
                </div>
            </div>
            <br><br><br><br><br><br><br><br><br>
            <footer><p>#Bibliophile &copy; Copyright 2021 by Ayush Binji</p></footer>
        </body>
</html>
