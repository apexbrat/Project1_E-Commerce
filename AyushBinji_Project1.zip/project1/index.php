<!doctype html>
<html lang="en">
    <head>
        <title>Home | Bibliophile</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="style.css">
    </head>
        <body>
            <div class="container-fluid">
                <br>
                <h3>Notice for Customers</h3>
                <p>We have recently updated our Privacy Policy. The site uses cookies to offer you a better experience. By continuing to browse the site you accept our Cookie Policy, you can change your settings at any time.</p>
                <p><strong>Note: </strong>Stay at home except for essential travel and follow the <a href="https://covid-19.ontario.ca/zones-and-restrictions">restrictions and public health measures.</a></p>

            </div>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="index.php">#Bibliophile</a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="bookstore.php">Select Books</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="checkout.php">Checkout</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container">
                <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="images/ban2.png" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="images/ban1.jpeg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="images/ban3.png" class="d-block w-100" alt="...">
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="heading">
                <h2>Take a look at our New Bestsellers! <span class="badge bg-primary">New</span></h2>
            </div>
            <br>
            <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div class="card text-center" style="width: 18rem;">
                            <img src="images/jenna.jpg" class="card-img-top" alt="Book Image">
                            <div class="card-body">
                                <h5 class="card-title">The Actor's Life</h5>
                                <p class="card-text">By Jenna Fischer</p>
                                <p><strong>£12.99</strong></p>
                                <p>Paperback</p>
                                <a href="bookstore.php" class="card-link">Details</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card text-center" style="width: 18rem;">
                            <img src="images/soulja.jpg" class="card-img-top" alt="Book Image">
                            <div class="card-body">
                                <h5 class="card-title">Life After Death</h5>
                                <p class="card-text">By Sister Souljah</p>
                                <p><strong>£20.00</strong></p>
                                <p>Hardback</p>
                                <a href="bookstore.php" class="card-link">Details</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm">
                        <div class="card text-center" style="width: 18rem;">
                            <img src="images/king.jpg" class="card-img-top" alt="Book Image">
                            <div class="card-body">
                                <h5 class="card-title">Later</h5>
                                <p class="card-text">By Stephen King</p>
                                <p><strong>£20.00</strong></p>
                                <p>Paperback</p>
                                <a href="bookstore.php" class="card-link">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="container">
                <div class="card text-center">
                    <div class="card-header">
                        Featured
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">Deals of the Week!</h5>
                        <p class="card-text">Speacial Mother's Day Sale. 25% Off on everything!</p>
                        <a href="bookstore.php" class="btn btn-primary">Shop Now</a>
                    </div>
                    <div class="card-footer text-muted">
                        2 days ago
                    </div>
                </div>
            </div>
            <br><br>
            <footer><p>#Bibliophile &copy; Copyright 2021 by Ayush Binji</p></footer>
        </body>
</html>
