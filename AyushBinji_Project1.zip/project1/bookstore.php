<!doctype html>
<html lang="en">
    <head>
        <title>Books | Bibliophile</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="style.css">
    </head>
        <body>

            <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
                <div class="container">
                    <a class="navbar-brand" href="index.php">#Bibliophile</a>
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="bookstore.php">Select Books</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="checkout.php">Checkout</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container">

                <?php

                    require('mysqli_connect.php');
                    ini_set('display_errors', 1);

                    $q = "SELECT book_ID, book_name, book_price, book_bio, book_pub_year, book_stock, auth_name, pub_name, cat_name FROM author
                    JOIN books ON author.auth_ID = books.auth_ID
                    JOIN publisher ON books.pub_ID = publisher.pub_ID
                    JOIN category ON books.cat_ID = category.cat_ID";

                    $r = mysqli_query($connection, $q);

                    $num = mysqli_num_rows($r);

                    if($num > 0) {
                        while($row = mysqli_fetch_array($r, MYSQLI_ASSOC)){
                        ?>
                            <a href="checkout.php?id=<?php echo $row['book_ID']; ?>">
                            <br>Title: <?php echo $row['book_name']; ?><br>
                            Price: £<?php echo $row['book_price']; ?><br>
                            Bio: <?php echo $row['book_bio']; ?><br>
                            Published Year: <?php echo $row['book_pub_year']; ?><br>
                            Stock: <?php echo $row['book_stock']; ?><br>
                            Author: <?php echo $row['auth_name']; ?></a><br>
                            Publisher: <?php echo $row['pub_name']; ?></a><br>
                            Category: <?php echo $row['cat_name']; ?></a><br>
                            <hr>    
                        <?php
                        } 
                       mysqli_free_result($r);
                        
                    }else {
                        echo '<br>No books Available in the Database.';
                    }
                    mysqli_close($connection);

                ?>
            </div>
            <br>

            <footer><p>#Bibliophile &copy; Copyright 2021 by Ayush Binji</p></footer>
        </body>
</html>

